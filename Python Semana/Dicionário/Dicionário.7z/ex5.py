d = {}
while True:
    nota = str(input('Digite Nome do aluno: '))
    d[nota] = int(input('Digite a Nota do Estúpido: '))
    cont = str(input('Deseja Continuar? [S/N]'))
    if cont in 'Nn':
        print(d)
        break