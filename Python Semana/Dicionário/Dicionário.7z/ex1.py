d1 = {1,2,3}
d2 = {3,4,5}
d2.update(d1)
print(d2)
