class instrumento:
    def __init__(self,nome):
        self.nome = nome
    def tocar(self):
        print(f'O {self.nome} está tocando')
class piano(instrumento):
    def __init__(self, nome):
        super().__init__(nome)
class violino(instrumento):
    def __init__(self, nome):
        super().__init__(nome)
motinha = violino('Violino')
motinha.tocar()